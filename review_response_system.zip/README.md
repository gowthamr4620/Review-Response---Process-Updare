# Review Response Prompt System - Test Harness

## What this is
A runnable version of the redesigned review-response prompt system, built to
be tested with Claude Code using your own API key across 5 real clients.

## Structure
```
config/
  client_config_schema.py   - config data model (tone/length enums, validation)
  persona_pools.py          - platform-owned, one persona per tone (not client-editable)
  clients.py                - FILL THIS IN: real config for your 5 clients
scripts/
  build_prompt.py           - the prompt builder itself
  run_batch.py               - calls the LLM API across all clients' review files
  diagnose_repetition.py     - checks output for repetition patterns
data/
  (put each client's review export here, referenced from clients.py)
output/
  (generated CSVs land here)
```

## Before running

1. Fill in `config/clients.py` with real values for each of the 5 clients:
   business_name, tone, length, custom_instructions, contact info, signature,
   brand_keywords, and the path to that client's reviews file.

2. Put each client's review export (xlsx or csv) in `data/`. Expected columns:
   `ReviewerName`, `Rating`, `Review` (extra columns ignored). If a client's
   export uses different column names, edit `COLUMN_MAP` in `run_batch.py`
   rather than renaming the source file.

3. Set your API key as an environment variable - never paste it into a file:
   ```
   export ANTHROPIC_API_KEY=sk-ant-...
   ```
   or
   ```
   export OPENAI_API_KEY=sk-...
   ```

## Running

Quick iteration (30 sampled reviews per client):
```
python scripts/run_batch.py --provider anthropic --sample 30
```

Single client only:
```
python scripts/run_batch.py --provider anthropic --sample 30 --client candere
```

Full run, all clients, all reviews (once you're happy with sampled results):
```
python scripts/run_batch.py --provider anthropic
```

## Diagnosing output

Per-client file:
```
python scripts/diagnose_repetition.py output/candere_output.csv
```

Cross-client check (catches repetition patterns that repeat ACROSS clients,
not just within one - e.g. two clients converging on the same generic
language despite different personas/tone):
```
python scripts/diagnose_repetition.py output/combined_output.csv --by-client
```

## What to actually look for in the diagnostic output

- Opening word/opening-pattern share above ~30% = still converging, needs
  another iteration on the grounding rule or response-objective pool.
- "Greet then thank" structural pattern above ~15% = the old skeleton is
  still leaking through regardless of word choice.
- Any single 5+ letter word appearing in >40% of one client's responses =
  new de facto stock phrase, even without a ban list forcing it. This is
  the check that replaces a maintained ban list - the model gets flagged
  for *actual* drift instead of you pre-guessing which word it'll be.

## Iterating

This is meant to be run, diagnosed, and adjusted in a loop:
1. Run a sample batch.
2. Run the diagnostic.
3. If a pattern is flagged, adjust the relevant prompt section in
   `build_prompt.py` (usually the Mandatory Grounding Rule or Response
   Variety section - avoid the temptation to add a banned-word list, since
   that's the reactive pattern this whole system was built to avoid).
4. Re-run and re-diagnose until flags clear.
